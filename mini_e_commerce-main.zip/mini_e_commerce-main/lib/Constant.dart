import 'package:flutter/material.dart';

var lightColor1=Color(0xff9c27b3);
var colorOnTopOfColor1= Colors.white;